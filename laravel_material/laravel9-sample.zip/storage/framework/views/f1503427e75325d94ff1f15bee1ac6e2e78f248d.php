<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
    </head>
    <body>
        <table>
            <tr><th>ID</th><th>name</th></tr>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('customer.show', ['id' => $customer->id])); ?>"><?php echo e($customer->id); ?></a></td>
                    <td><?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html>
<?php /**PATH /var/www/html/resources/views/customer/index.blade.php ENDPATH**/ ?>