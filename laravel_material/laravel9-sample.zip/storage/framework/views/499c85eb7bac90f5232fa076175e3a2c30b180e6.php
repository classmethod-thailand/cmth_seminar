<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
    </head>
    <body>
        <ul>
            <li>ID: <?php echo e($customer->id); ?></li>
            <li>Name: <?php echo e($customer->firstname); ?> <?php echo e($customer->lastname); ?></li>
        </ul>

        <p><a href="<?php echo e(route('customer.index')); ?>">Index</a></p>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/customer/show.blade.php ENDPATH**/ ?>