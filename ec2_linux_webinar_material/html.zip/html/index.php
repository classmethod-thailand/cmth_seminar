<!DOCTYPE html>
<html lang="en">

<head>
  <title>Classmethod Thailand</title>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body class="body_en">

  <div class="container">
    <div class="row">
      <div class="col-sm-6 mt-5">
        <p style="color:#4E7CCE;" class="h1">Providing continous<br>
          support of
        </p>
        <p style="color:#2CAFBF;" class="h2">creative activity<br>
          to all people by <?php echo date("c"); ?>
        </p>
      </div>
      <div class="col-sm-6">
        <img src="images/home_edit.png" class="img-fluid" alt="Responsive image"
          width="650" height="450">
      </div>

      <div class="col-sm-6 mt-5">
        <img src="images/about-us.png" class="img-fluid" alt="Responsive image"
          width="600" height="400">
      </div>
      <div class="col-sm-6 mt-5">
        <h1 class="text-right" style="color:#3A9DDA">About Us</h1>
        <!-- <div class="right-border"></div> -->
        <p class="text-right h5 mt-3 mb-5" style="color:#777777;">
          We consult, design and develop systems specialized in Amazon Web Services (AWS), mobile applications, and big
          data analytics. To realize our mission, we abide by the following three principle
        </p>
        <a type="button" class="btn btn-primary float-right btn-lg"
          href="#">Read more</a>
      </div>
    </div>
  </div>

</body>

</html>